"""
Distance and Similarity Measures

Different measures of distance or similarity for different types of analysis.
"""
