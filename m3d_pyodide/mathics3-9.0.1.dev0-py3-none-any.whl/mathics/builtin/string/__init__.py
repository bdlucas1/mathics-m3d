"""
Strings and Characters

"""
# FIXME: Redo. This is a Tech note, not a Guide Section.
