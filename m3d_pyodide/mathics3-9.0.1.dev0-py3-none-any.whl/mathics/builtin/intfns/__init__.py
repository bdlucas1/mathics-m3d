"""
Integer Functions

Integer Functions can work on integers of any size.
"""

from mathics.version import __version__  # noqa used in loading to check consistency.
