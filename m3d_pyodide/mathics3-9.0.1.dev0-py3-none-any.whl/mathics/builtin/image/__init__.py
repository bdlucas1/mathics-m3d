"""
Image Manipulation


For the full compliment of functions, you need to have <url>:scikit-image:
https://scikit-image.org/</url>
installed.
"""
