(* Text Importer *)

Begin["System`Convert`Package`"]

ImportExport`RegisterImport[
    "Package",
    System`Get
]

End[]
