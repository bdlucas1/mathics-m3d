(***********************************)
(* Settings for Mathics CLI script *)
(***********************************)

System`$Notebooks::usage = "Set True if the Mathics is being used with a notebook-based front end.";
System`$Notebooks = False;
