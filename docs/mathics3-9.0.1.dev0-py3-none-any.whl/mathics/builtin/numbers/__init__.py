"""
Integer and Number-Theoretical Functions
"""

# This tells documentation how to sort this module
sort_order = "mathics.builtin.integer-and-number-theoretical-functions"
