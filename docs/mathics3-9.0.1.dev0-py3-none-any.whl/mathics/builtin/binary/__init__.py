# -*- coding: utf-8 -*-

"""
Binary Data

Binary data is a type of data that is represented in the binary, sequences of zeros or ones. Computer-generated information often comes in this form.
"""

# This tells documentation how to sort this module
sort_order = "mathics.builtin.binary-data"
