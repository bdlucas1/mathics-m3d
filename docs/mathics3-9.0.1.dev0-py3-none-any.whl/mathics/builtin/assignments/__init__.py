"""
Assignments

Assignments allow you to set or clear variables, indexed variables, \
structure elements, functions, and general transformations.

You can also get assignment and documentation information about symbols.
"""
