# -*- coding: utf-8 -*-
"""
Atomic Elements of Expressions

Expressions are ultimately built from a small number of distinct types of atomic elements.
"""
