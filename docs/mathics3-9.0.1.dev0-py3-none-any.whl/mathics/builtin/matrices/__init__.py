"""
Matrices and Linear Algebra

Construction and manipulation of Matrices.
"""

from mathics.version import __version__  # noqa used in loading to check consistency.
