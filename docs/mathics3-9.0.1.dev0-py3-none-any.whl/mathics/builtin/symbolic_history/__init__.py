"""
Symbolic Execution History

In order to debug and understand program execution, the execution history can be saved.
"""
sort_order = "mathics.builtin.symbolic-execution-history"
