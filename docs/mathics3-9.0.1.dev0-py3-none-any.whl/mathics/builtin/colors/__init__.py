"""
Colors

Programmatic support for symbolic colors.

"""
