# -*- coding: utf-8 -*-
"""
Evaluation functions in support of builtin functions under mathics.builtin.numbers
"""
