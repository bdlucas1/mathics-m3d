# -*- coding: utf-8 -*-
"""
Implementation of  mathics.builtin.numbers.algebra
"""
