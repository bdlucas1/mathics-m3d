"""
Evaluation methods in support of Input/Output, Files, and the Filesystem.
"""
